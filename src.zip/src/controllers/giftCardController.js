/**
 * Gift Card Controller - Global Bank Nigeria
 * Real Gift Card Trading Logic
 */

const crypto = require('crypto');
const GiftCard = require('../models/GiftCard');
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const { sendEmail } = require('../utils/email');

// Get available gift cards
exports.getAvailableCards = async (req, res) => {
  try {
    const { type, minAmount, maxAmount } = req.query;

    const query = {
      status: 'available',
      isVerified: true,
      isFake: false,
    };

    if (type) query.cardType = type;
    if (minAmount) query.amount = { ...query.amount, $gte: minAmount };
    if (maxAmount) query.amount = { ...query.amount, $lte: maxAmount };

    const cards = await GiftCard.find(query)
      .sort({ amount: 1 })
      .limit(50);

    res.status(200).json({
      success: true,
      count: cards.length,
      data: cards,
    });
  } catch (error) {
    console.error('Get available cards error:', error);
    res.status(500).json({
      success: false,
      message: 'Error retrieving available cards',
      error: error.message,
    });
  }
};

// Get card types
exports.getCardTypes = async (req, res) => {
  try {
    const types = [
      { type: 'amazon', name: 'Amazon Gift Card', icon: '🛒', rate: 750 },
      { type: 'itunes', name: 'iTunes Gift Card', icon: '🎵', rate: 730 },
      { type: 'google', name: 'Google Play Gift Card', icon: '🎮', rate: 720 },
      { type: 'apple', name: 'Apple Store Gift Card', icon: '🍎', rate: 740 },
      { type: 'steam', name: 'Steam Gift Card', icon: '🎲', rate: 700 },
      { type: 'sephora', name: 'Sephora Gift Card', icon: '💄', rate: 710 },
      { type: 'global', name: 'Global Card', icon: '🌍', rate: 800 },
    ];

    res.status(200).json({
      success: true,
      data: types,
    });
  } catch (error) {
    console.error('Get card types error:', error);
    res.status(500).json({
      success: false,
      message: 'Error retrieving card types',
      error: error.message,
    });
  }
};

// Get current rates
exports.getCurrentRates = async (req, res) => {
  try {
    const rates = {
      USD: {
        toNGN: 750,
        updated: new Date().toISOString(),
      },
      giftCards: {
        amazon: { rate: 750, minAmount: 1, maxAmount: 10000 },
        itunes: { rate: 730, minAmount: 1, maxAmount: 10000 },
        google: { rate: 720, minAmount: 1, maxAmount: 10000 },
        apple: { rate: 740, minAmount: 1, maxAmount: 10000 },
        steam: { rate: 700, minAmount: 1, maxAmount: 10000 },
        sephora: { rate: 710, minAmount: 1, maxAmount: 10000 },
        global: { rate: 800, minAmount: 1, maxAmount: 10000 },
      },
    };

    res.status(200).json({
      success: true,
      data: rates,
    });
  } catch (error) {
    console.error('Get current rates error:', error);
    res.status(500).json({
      success: false,
      message: 'Error retrieving current rates',
      error: error.message,
    });
  }
};

// Purchase gift card
exports.purchaseCard = async (req, res) => {
  try {
    const { cardType, amount, quantity } = req.body;
    const userId = req.user.id;

    // Find available cards
    const availableCards = await GiftCard.find({
      cardType,
      amount,
      status: 'available',
      isVerified: true,
      isFake: false,
    }).limit(quantity);

    if (availableCards.length < quantity) {
      return res.status(400).json({
        success: false,
        message: `Not enough cards available. Only ${availableCards.length} cards available.`,
      });
    }

    // Calculate total cost
    const rate = 750; // Default rate
    const totalCost = amount * quantity * rate;

    // Check user balance
    const user = await User.findById(userId);
    if (user.accountBalance < totalCost) {
      return res.status(400).json({
        success: false,
        message: 'Insufficient balance',
        required: totalCost,
        available: user.accountBalance,
      });
    }

    // Create transaction
    const transaction = await Transaction.create({
      type: 'gift-card-purchase',
      from: {
        user: userId,
        accountNumber: user.accountNumber,
      },
      to: {
        user: userId, // Admin user
      },
      amount: totalCost,
      currency: 'NGN',
      fee: totalCost * 0.02, // 2% fee
      status: 'pending',
      giftCardType: cardType,
      giftCardAmount: amount * quantity,
      ipAddress: req.ip,
    });

    // Mark cards as sold
    const cardIds = availableCards.map(card => card._id);
    await GiftCard.updateMany(
      { _id: { $in: cardIds } },
      {
        status: 'sold',
        currentHolder: userId,
        purchasedAt: Date.now(),
        $push: {
          transactions: {
            type: 'sold',
            to: userId,
            amount,
            transactionId: transaction.transactionId,
            timestamp: Date.now(),
          },
        },
      }
    );

    // Complete transaction
    await transaction.complete();

    // Send email notification
    await sendEmail({
      to: user.email,
      subject: 'Gift Card Purchase Successful - Global Bank Nigeria',
      html: `
        <h2>Gift Card Purchase Successful</h2>
        <p>Dear ${user.fullName},</p>
        <p>You have successfully purchased ${quantity} ${cardType} gift card(s) worth $${amount} each.</p>
        <p><strong>Transaction ID:</strong> ${transaction.transactionId}</p>
        <p><strong>Total Paid:</strong> ₦${totalCost.toLocaleString()}</p>
        <p>Your gift cards are now available in your account.</p>
        <p>Best regards,<br>Global Bank Nigeria Team</p>
      `,
    });

    res.status(200).json({
      success: true,
      message: 'Gift card purchased successfully',
      data: {
        transaction: transaction,
        cards: availableCards,
      },
    });
  } catch (error) {
    console.error('Purchase card error:', error);
    res.status(500).json({
      success: false,
      message: 'Error purchasing gift card',
      error: error.message,
    });
  }
};

// Sell gift card
exports.sellCard = async (req, res) => {
  try {
    const { cardType, cardNumber, pin, amount, cardImage } = req.body;
    const userId = req.user.id;

    // Verify card (in real system, this would check with card provider)
    const card = await GiftCard.findByCardNumber(cardNumber);

    if (!card) {
      return res.status(404).json({
        success: false,
        message: 'Card not found in system',
      });
    }

    // Check card status
    const verification = card.verify();
    if (!verification.isValid) {
      return res.status(400).json({
        success: false,
        message: 'Card is not valid for sale',
        verification,
      });
    }

    // Calculate sale value
    const rate = 750; // Default rate
    const saleValue = amount * rate;

    // Create transaction
    const transaction = await Transaction.create({
      type: 'gift-card-sale',
      from: {
        user: userId,
      },
      to: {
        user: null, // Admin
      },
      amount: saleValue,
      currency: 'NGN',
      fee: saleValue * 0.05, // 5% fee
      status: 'pending',
      giftCard: card._id,
      giftCardType: cardType,
      giftCardAmount: amount,
      ipAddress: req.ip,
      requiresManualReview: true, // Manual review for sales
    });

    res.status(200).json({
      success: true,
      message: 'Gift card submitted for sale. Pending verification.',
      data: {
        transaction,
        estimatedValue: saleValue * 0.95, // After fee
      },
    });
  } catch (error) {
    console.error('Sell card error:', error);
    res.status(500).json({
      success: false,
      message: 'Error selling gift card',
      error: error.message,
    });
  }
};

// Transfer gift card
exports.transferCard = async (req, res) => {
  try {
    const { cardId, recipientEmail, recipientAccountNumber, message } = req.body;
    const senderId = req.user.id;

    // Find card
    const card = await GiftCard.findById(cardId);

    if (!card) {
      return res.status(404).json({
        success: false,
        message: 'Card not found',
      });
    }

    // Check ownership
    if (card.currentHolder.toString() !== senderId) {
      return res.status(403).json({
        success: false,
        message: 'You do not own this card',
      });
    }

    // Find recipient
    const recipient = await User.findOne({
      $or: [
        { email: recipientEmail },
        { accountNumber: recipientAccountNumber },
      ],
    });

    if (!recipient) {
      return res.status(404).json({
        success: false,
        message: 'Recipient not found',
      });
    }

    // Transfer card
    await card.transfer(recipient._id, `TXN${Date.now()}`);

    // Create transaction
    const transaction = await Transaction.create({
      type: 'gift-card-transfer',
      from: {
        user: senderId,
        accountNumber: req.user.accountNumber,
      },
      to: {
        user: recipient._id,
        accountNumber: recipient.accountNumber,
      },
      amount: card.amount,
      currency: 'USD',
      giftCard: card._id,
      giftCardType: card.cardType,
      giftCardAmount: card.amount,
      status: 'completed',
      notes: message,
      ipAddress: req.ip,
    });

    await transaction.complete();

    // Send notifications
    await sendEmail({
      to: recipient.email,
      subject: 'Gift Card Received - Global Bank Nigeria',
      html: `
        <h2>Gift Card Received</h2>
        <p>Dear ${recipient.fullName},</p>
        <p>You have received a ${card.cardType} gift card worth $${card.amount} from ${req.user.fullName}.</p>
        <p><strong>Transaction ID:</strong> ${transaction.transactionId}</p>
        <p><strong>Message:</strong> ${message || 'No message'}</p>
        <p>Best regards,<br>Global Bank Nigeria Team</p>
      `,
    });

    res.status(200).json({
      success: true,
      message: 'Gift card transferred successfully',
      data: {
        transaction,
        card,
      },
    });
  } catch (error) {
    console.error('Transfer card error:', error);
    res.status(500).json({
      success: false,
      message: 'Error transferring gift card',
      error: error.message,
    });
  }
};

// Get my cards
exports.getMyCards = async (req, res) => {
  try {
    const userId = req.user.id;
    const { status, type } = req.query;

    const query = { currentHolder: userId };
    if (status) query.status = status;
    if (type) query.cardType = type;

    const cards = await GiftCard.find(query)
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: cards.length,
      data: cards,
    });
  } catch (error) {
    console.error('Get my cards error:', error);
    res.status(500).json({
      success: false,
      message: 'Error retrieving your cards',
      error: error.message,
    });
  }
};

// Get card by ID
exports.getCardById = async (req, res) => {
  try {
    const { cardId } = req.params;
    const userId = req.user.id;

    const card = await GiftCard.findById(cardId);

    if (!card) {
      return res.status(404).json({
        success: false,
        message: 'Card not found',
      });
    }

    // Check ownership
    if (card.currentHolder.toString() !== userId && card.owner.toString() !== userId) {
      return res.status(403).json({
        success: false,
        message: 'You do not have permission to view this card',
      });
    }

    res.status(200).json({
      success: true,
      data: card,
    });
  } catch (error) {
    console.error('Get card by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Error retrieving card',
      error: error.message,
    });
  }
};

// Verify card
exports.verifyCard = async (req, res) => {
  try {
    const { cardNumber } = req.body;

    const card = await GiftCard.findByCardNumber(cardNumber);

    if (!card) {
      return res.status(404).json({
        success: false,
        message: 'Card not found',
        verification: {
          isValid: false,
          isUsed: false,
          isFake: true,
          status: 'not-found',
          message: 'Card number not recognized in our system',
        },
      });
    }

    const verification = card.verify();

    res.status(200).json({
      success: true,
      data: verification,
    });
  } catch (error) {
    console.error('Verify card error:', error);
    res.status(500).json({
      success: false,
      message: 'Error verifying card',
      error: error.message,
    });
  }
};

// Scan card (barcode)
exports.scanCard = async (req, res) => {
  try {
    const { barcodeData } = req.body;

    // Find card by barcode
    const card = await GiftCard.findOne({
      'barcode.data': barcodeData,
    });

    if (!card) {
      return res.status(404).json({
        success: false,
        message: 'Card not found',
      });
    }

    const verification = card.verify();

    res.status(200).json({
      success: true,
      data: {
        card,
        verification,
      },
    });
  } catch (error) {
    console.error('Scan card error:', error);
    res.status(500).json({
      success: false,
      message: 'Error scanning card',
      error: error.message,
    });
  }
};

// Admin: Get all cards
exports.getAllCards = async (req, res) => {
  try {
    const { status, type, page = 1, limit = 50 } = req.query;

    const query = {};
    if (status) query.status = status;
    if (type) query.cardType = type;

    const cards = await GiftCard.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .populate('owner', 'firstName lastName email')
      .populate('currentHolder', 'firstName lastName email');

    const total = await GiftCard.countDocuments(query);

    res.status(200).json({
      success: true,
      count: cards.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: cards,
    });
  } catch (error) {
    console.error('Get all cards error:', error);
    res.status(500).json({
      success: false,
      message: 'Error retrieving all cards',
      error: error.message,
    });
  }
};

// Admin: Generate cards
exports.generateCards = async (req, res) => {
  try {
    const { cardType, amount, quantity } = req.body;

    const cards = [];
    for (let i = 0; i < quantity; i++) {
      const card = await GiftCard.create({
        cardType,
        cardName: cardType.charAt(0).toUpperCase() + cardType.slice(1),
        amount,
        status: 'available',
        isGlobalCard: cardType === 'global',
        globalCardOwner: cardType === 'global' ? {
          name: 'Olawale Abdul-ganiyu',
          email: 'adeganglobal@gmail.com',
        } : undefined,
      });
      cards.push(card);
    }

    res.status(201).json({
      success: true,
      message: `${quantity} cards generated successfully`,
      data: cards,
    });
  } catch (error) {
    console.error('Generate cards error:', error);
    res.status(500).json({
      success: false,
      message: 'Error generating cards',
      error: error.message,
    });
  }
};

// Admin: Add card type
exports.addCardType = async (req, res) => {
  try {
    const { type, name, icon, rate, minAmount, maxAmount } = req.body;

    // This would be stored in a CardTypes collection
    res.status(201).json({
      success: true,
      message: 'Card type added successfully',
      data: { type, name, icon, rate, minAmount, maxAmount },
    });
  } catch (error) {
    console.error('Add card type error:', error);
    res.status(500).json({
      success: false,
      message: 'Error adding card type',
      error: error.message,
    });
  }
};

// Admin: Update card
exports.updateCard = async (req, res) => {
  try {
    const { cardId } = req.params;
    const updates = req.body;

    const card = await GiftCard.findByIdAndUpdate(cardId, updates, {
      new: true,
      runValidators: true,
    });

    if (!card) {
      return res.status(404).json({
        success: false,
        message: 'Card not found',
      });
    }

    res.status(200).json({
      success: true,
      message: 'Card updated successfully',
      data: card,
    });
  } catch (error) {
    console.error('Update card error:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating card',
      error: error.message,
    });
  }
};

// Admin: Delete card
exports.deleteCard = async (req, res) => {
  try {
    const { cardId } = req.params;

    const card = await GiftCard.findByIdAndDelete(cardId);

    if (!card) {
      return res.status(404).json({
        success: false,
        message: 'Card not found',
      });
    }

    res.status(200).json({
      success: true,
      message: 'Card deleted successfully',
    });
  } catch (error) {
    console.error('Delete card error:', error);
    res.status(500).json({
      success: false,
      message: 'Error deleting card',
      error: error.message,
    });
  }
};

// Admin: Get statistics
exports.getStatistics = async (req, res) => {
  try {
    const stats = await GiftCard.getStatistics();

    res.status(200).json({
      success: true,
      data: stats,
    });
  } catch (error) {
    console.error('Get statistics error:', error);
    res.status(500).json({
      success: false,
      message: 'Error retrieving statistics',
      error: error.message,
    });
  }
};