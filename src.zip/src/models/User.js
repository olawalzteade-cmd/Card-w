/**
 * User Model - Global Bank Nigeria
 * MongoDB Schema with Real Authentication
 */

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
  // Personal Information
  firstName: {
    type: String,
    required: [true, 'First name is required'],
    trim: true,
    maxlength: [50, 'First name cannot exceed 50 characters'],
  },
  lastName: {
    type: String,
    required: [true, 'Last name is required'],
    trim: true,
    maxlength: [50, 'Last name cannot exceed 50 characters'],
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [
      /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
      'Please provide a valid email address',
    ],
  },
  phoneNumber: {
    type: String,
    required: [true, 'Phone number is required'],
    unique: true,
    trim: true,
  },
  countryCode: {
    type: String,
    required: [true, 'Country code is required'],
    default: '+234',
  },
  dateOfBirth: {
    type: Date,
    required: [true, 'Date of birth is required'],
  },
  address: {
    street: String,
    city: String,
    state: String,
    country: String,
    zipCode: String,
  },

  // Account Information
  accountNumber: {
    type: String,
    unique: true,
    required: true,
  },
  accountBalance: {
    type: Number,
    default: 0,
    min: [0, 'Balance cannot be negative'],
  },
  creditBalance: {
    type: Number,
    default: 0,
    min: [0, 'Credit balance cannot be negative'],
  },
  debitBalance: {
    type: Number,
    default: 0,
    min: [0, 'Debit balance cannot be negative'],
  },
  pendingBalance: {
    type: Number,
    default: 0,
  },

  // Authentication
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [8, 'Password must be at least 8 characters'],
    select: false,
  },
  role: {
    type: String,
    enum: ['user', 'admin', 'super-admin'],
    default: 'user',
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  isKYCVerified: {
    type: Boolean,
    default: false,
  },
  kycLevel: {
    type: Number,
    enum: [0, 1, 2, 3, 4],
    default: 0,
  },

  // KYC Information
  idType: {
    type: String,
    enum: ['passport', 'national-id', 'drivers-license', 'voters-card'],
  },
  idNumber: String,
  idDocument: {
    url: String,
    uploadedAt: Date,
    verified: Boolean,
    verifiedAt: Date,
  },
  passportPhoto: {
    url: String,
    uploadedAt: Date,
    verified: Boolean,
  },
  bvn: {
    type: String,
    length: 11,
  },
  kycSubmittedAt: Date,
  kycVerifiedAt: Date,

  // Security
  twoFactorEnabled: {
    type: Boolean,
    default: false,
  },
  twoFactorSecret: String,
  passwordChangedAt: Date,
  failedLoginAttempts: {
    type: Number,
    default: 0,
  },
  lockUntil: Date,
  refreshToken: String,
  resetPasswordToken: String,
  resetPasswordExpire: Date,
  emailVerificationToken: String,
  emailVerificationExpire: Date,

  // Bank Account
  bankAccounts: [{
    bankName: String,
    accountNumber: String,
    accountName: String,
    isDefault: Boolean,
    addedAt: { type: Date, default: Date.now },
  }],

  // Crypto Wallets
  cryptoWallets: {
    bitcoin: {
      address: String,
      balance: { type: Number, default: 0 },
    },
    ethereum: {
      address: String,
      balance: { type: Number, default: 0 },
    },
    'bitcoin-cash': {
      address: String,
      balance: { type: Number, default: 0 },
    },
    tron: {
      address: String,
      balance: { type: Number, default: 0 },
    },
    ton: {
      address: String,
      balance: { type: Number, default: 0 },
    },
  },

  // Statistics
  totalTransactions: {
    type: Number,
    default: 0,
  },
  totalVolume: {
    type: Number,
    default: 0,
  },
  successfulTransactions: {
    type: Number,
    default: 0,
  },

  // Timestamps
  lastLogin: Date,
  lastLoginIP: String,
  loginHistory: [{
    timestamp: Date,
    ip: String,
    device: String,
    location: String,
  }],
}, {
  timestamps: true,
});

// Indexes
userSchema.index({ email: 1 });
userSchema.index({ accountNumber: 1 });
userSchema.index({ phoneNumber: 1 });
userSchema.index({ role: 1 });
userSchema.index({ createdAt: -1 });

// Pre-save middleware
userSchema.pre('save', async function(next) {
  // Hash password if modified
  if (!this.isModified('password')) return next();

  try {
    const salt = await bcrypt.genSalt(parseInt(process.env.BCRYPT_ROUNDS) || 12);
    this.password = await bcrypt.hash(this.password, salt);
    this.passwordChangedAt = Date.now();
    next();
  } catch (error) {
    next(error);
  }
});

// Generate account number
userSchema.pre('save', async function(next) {
  if (!this.isNew) return next();

  try {
    const count = await this.constructor.countDocuments();
    this.accountNumber = (1000000000 + count).toString();
    next();
  } catch (error) {
    next(error);
  }
});

// Instance methods
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

userSchema.methods.generateAuthToken = function() {
  const payload = {
    id: this._id,
    email: this.email,
    accountNumber: this.accountNumber,
    role: this.role,
  };

  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '7d',
  });
};

userSchema.methods.generateRefreshToken = function() {
  const payload = {
    id: this._id,
    type: 'refresh',
  };

  return jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRE || '30d',
  });
};

userSchema.methods.createPasswordResetToken = function() {
  const resetToken = crypto.randomBytes(32).toString('hex');
  this.resetPasswordToken = crypto
    .createHash('sha256')
    .update(resetToken)
    .digest('hex');
  this.resetPasswordExpire = Date.now() + 10 * 60 * 1000; // 10 minutes
  return resetToken;
};

userSchema.methods.createEmailVerificationToken = function() {
  const verificationToken = crypto.randomBytes(32).toString('hex');
  this.emailVerificationToken = crypto
    .createHash('sha256')
    .update(verificationToken)
    .digest('hex');
  this.emailVerificationExpire = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
  return verificationToken;
};

userSchema.methods.isAccountLocked = function() {
  return !!(this.lockUntil && this.lockUntil > Date.now());
};

userSchema.methods.incrementFailedLogin = function() {
  this.failedLoginAttempts += 1;
  
  if (this.failedLoginAttempts >= 5) {
    this.lockUntil = Date.now() + 15 * 60 * 1000; // Lock for 15 minutes
  }
  
  return this.save();
};

userSchema.methods.resetFailedLogin = function() {
  this.failedLoginAttempts = 0;
  this.lockUntil = undefined;
  return this.save();
};

userSchema.methods.recordLogin = function(ip, device, location) {
  this.lastLogin = Date.now();
  this.lastLoginIP = ip;
  this.loginHistory.push({
    timestamp: Date.now(),
    ip,
    device,
    location,
  });
  
  // Keep only last 20 logins
  if (this.loginHistory.length > 20) {
    this.loginHistory = this.loginHistory.slice(-20);
  }
  
  return this.save();
};

// Static methods
userSchema.statics.createDefaultAdmin = async function() {
  try {
    const adminExists = await this.findOne({ role: 'super-admin' });
    
    if (!adminExists) {
      const admin = await this.create({
        firstName: 'Olawale',
        lastName: 'Abdul-ganiyu',
        email: process.env.ADMIN_EMAIL || 'adeganglobal@gmail.com',
        phoneNumber: '+2348000000000',
        password: process.env.ADMIN_PASSWORD || 'AdminPass2024!@#',
        role: 'super-admin',
        isVerified: true,
        isKYCVerified: true,
        kycLevel: 4,
      });
      
      console.log('✅ Default admin account created:', admin.email);
    }
  } catch (error) {
    console.error('Error creating default admin:', error.message);
  }
};

userSchema.statics.findByEmailOrPhone = function(identifier) {
  return this.findOne({
    $or: [
      { email: identifier },
      { phoneNumber: identifier },
      { accountNumber: identifier },
    ],
  });
};

// Virtual
userSchema.virtual('fullName').get(function() {
  return `${this.firstName} ${this.lastName}`;
});

userSchema.virtual('canTransact').get(function() {
  return this.isActive && this.isVerified && this.isKYCVerified && !this.isAccountLocked();
});

// Ensure virtuals are included in JSON
userSchema.set('toJSON', { virtuals: true });
userSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('User', userSchema);