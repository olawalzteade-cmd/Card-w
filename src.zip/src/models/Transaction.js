/**
 * Transaction Model - Global Bank Nigeria
 * Real Transaction Processing System
 */

const mongoose = require('mongoose');
const crypto = require('crypto');

const transactionSchema = new mongoose.Schema({
  // Basic Information
  transactionId: {
    type: String,
    unique: true,
    required: true,
    index: true,
  },
  reference: {
    type: String,
    unique: true,
    required: true,
  },
  
  // Transaction Type
  type: {
    type: String,
    required: true,
    enum: [
      'gift-card-purchase',
      'gift-card-sale',
      'gift-card-transfer',
      'crypto-buy',
      'crypto-sell',
      'crypto-transfer',
      'deposit',
      'withdrawal',
      'transfer',
      'mining-reward',
      'refund',
      'chargeback',
    ],
  },
  
  // Participants
  from: {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    accountNumber: String,
    accountName: String,
    bankName: String,
    cryptoAddress: String,
  },
  to: {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    accountNumber: String,
    accountName: String,
    bankName: String,
    cryptoAddress: String,
  },
  
  // Amount Details
  amount: {
    type: Number,
    required: true,
  },
  currency: {
    type: String,
    required: true,
    default: 'NGN',
  },
  fee: {
    type: Number,
    default: 0,
  },
  netAmount: {
    type: Number,
  },
  exchangeRate: {
    type: Number,
  },
  
  // Gift Card Specific
  giftCard: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'GiftCard',
  },
  giftCardType: String,
  giftCardAmount: Number,
  
  // Crypto Specific
  cryptoType: {
    type: String,
    enum: ['bitcoin', 'ethereum', 'bitcoin-cash', 'tron', 'ton'],
  },
  cryptoAmount: Number,
  networkFee: Number,
  transactionHash: String,
  confirmations: {
    type: Number,
    default: 0,
  },
  
  // Status
  status: {
    type: String,
    required: true,
    enum: ['pending', 'processing', 'completed', 'failed', 'cancelled', 'reversed'],
    default: 'pending',
  },
  
  // Banking Details
  bankDetails: {
    bankName: String,
    accountNumber: String,
    accountName: String,
    sortCode: String,
    routingNumber: String,
  },
  
  // Payment Gateway
  paymentGateway: {
    provider: {
      type: String,
      enum: ['paystack', 'flutterwave', 'direct', 'manual'],
    },
    transactionReference: String,
    gatewayResponse: mongoose.Schema.Types.Mixed,
  },
  
  // Reason and Notes
  reason: String,
  notes: String,
  description: String,
  
  // AML/KYC
  isHighRisk: {
    type: Boolean,
    default: false,
  },
  riskScore: {
    type: Number,
    default: 0,
    min: 0,
    max: 100,
  },
  requiresManualReview: {
    type: Boolean,
    default: false,
  },
  reviewedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  reviewedAt: Date,
  
  // Fraud Detection
  isFlagged: {
    type: Boolean,
    default: false,
  },
  flagReason: String,
  fraudScore: {
    type: Number,
    default: 0,
  },
  
  // Notifications
  emailSent: {
    type: Boolean,
    default: false,
  },
  smsSent: {
    type: Boolean,
    default: false,
  },
  
  // IP and Device Information
  ipAddress: String,
  deviceInfo: String,
  location: {
    type: {
      type: String,
      enum: ['Point'],
    },
    coordinates: {
      type: [Number],
    },
  },
  
  // Timestamps
  initiatedAt: {
    type: Date,
    default: Date.now,
  },
  completedAt: Date,
  failedAt: Date,
  cancelledAt: Date,
}, {
  timestamps: true,
});

// Indexes
transactionSchema.index({ transactionId: 1 });
transactionSchema.index({ reference: 1 });
transactionSchema.index({ type: 1 });
transactionSchema.index({ status: 1 });
transactionSchema.index({ 'from.user': 1 });
transactionSchema.index({ 'to.user': 1 });
transactionSchema.index({ createdAt: -1 });

// Pre-save middleware
transactionSchema.pre('save', async function(next) {
  if (this.isNew) {
    // Generate transaction ID
    if (!this.transactionId) {
      this.transactionId = await this.generateTransactionId();
    }

    // Generate reference
    if (!this.reference) {
      this.reference = await this.generateReference();
    }

    // Calculate net amount
    this.netAmount = this.amount - this.fee;
  }

  next();
});

// Instance methods
transactionSchema.methods.generateTransactionId = async function() {
  const prefix = this.getTransactionPrefix();
  const timestamp = Date.now().toString().slice(-6);
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `TXN${prefix}${timestamp}${random}`.toUpperCase();
};

transactionSchema.methods.getTransactionPrefix = function() {
  const prefixes = {
    'gift-card-purchase': 'GCP',
    'gift-card-sale': 'GCS',
    'gift-card-transfer': 'GCT',
    'crypto-buy': 'CRY',
    'crypto-sell': 'CRS',
    'crypto-transfer': 'CRT',
    'deposit': 'DEP',
    'withdrawal': 'WDR',
    'transfer': 'TRF',
    'mining-reward': 'MIN',
    'refund': 'REF',
    'chargeback': 'CHB',
  };
  return prefixes[this.type] || 'TXN';
};

transactionSchema.methods.generateReference = async function() {
  return crypto.randomBytes(16).toString('hex').toUpperCase();
};

transactionSchema.methods.complete = async function() {
  this.status = 'completed';
  this.completedAt = Date.now();

  // Update user balance
  if (this.to.user) {
    const User = mongoose.model('User');
    const user = await User.findById(this.to.user);
    if (user) {
      user.accountBalance += this.netAmount;
      user.creditBalance += this.netAmount;
      user.totalTransactions += 1;
      user.totalVolume += this.amount;
      user.successfulTransactions += 1;
      await user.save();
    }
  }

  if (this.from.user) {
    const User = mongoose.model('User');
    const user = await User.findById(this.from.user);
    if (user) {
      user.accountBalance -= this.amount;
      user.debitBalance += this.amount;
      user.totalTransactions += 1;
      user.totalVolume += this.amount;
      await user.save();
    }
  }

  return this.save();
};

transactionSchema.methods.fail = async function(reason) {
  this.status = 'failed';
  this.failedAt = Date.now();
  this.notes = reason;

  return this.save();
};

transactionSchema.methods.cancel = async function(reason) {
  this.status = 'cancelled';
  this.cancelledAt = Date.now();
  this.notes = reason;

  return this.save();
};

transactionSchema.methods.reverse = async function() {
  this.status = 'reversed';

  // Reverse balance changes
  if (this.from.user) {
    const User = mongoose.model('User');
    const user = await User.findById(this.from.user);
    if (user) {
      user.accountBalance += this.amount;
      user.debitBalance -= this.amount;
      await user.save();
    }
  }

  if (this.to.user) {
    const User = mongoose.model('User');
    const user = await User.findById(this.to.user);
    if (user) {
      user.accountBalance -= this.netAmount;
      user.creditBalance -= this.netAmount;
      await user.save();
    }
  }

  return this.save();
};

// Static methods
transactionSchema.statics.findByTransactionId = function(transactionId) {
  return this.findOne({ transactionId });
};

transactionSchema.statics.findByReference = function(reference) {
  return this.findOne({ reference });
};

transactionSchema.statics.findByUser = function(userId) {
  return this.find({
    $or: [
      { 'from.user': userId },
      { 'to.user': userId },
    ],
  }).sort({ createdAt: -1 });
};

transactionSchema.statics.findByStatus = function(status) {
  return this.find({ status }).sort({ createdAt: -1 });
};

transactionSchema.statics.getStatistics = async function(userId = null) {
  const matchQuery = userId ? {
    $or: [
      { 'from.user': userId },
      { 'to.user': userId },
    ],
  } : {};

  const stats = await this.aggregate([
    { $match: matchQuery },
    {
      $group: {
        _id: null,
        totalTransactions: { $sum: 1 },
        totalVolume: { $sum: '$amount' },
        totalFees: { $sum: '$fee' },
        completedTransactions: {
          $sum: { $cond: [{ $eq: ['$status', 'completed'] }, 1, 0] },
        },
        pendingTransactions: {
          $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] },
        },
        failedTransactions: {
          $sum: { $cond: [{ $eq: ['$status', 'failed'] }, 1, 0] },
        },
        creditTransactions: {
          $sum: {
            $cond: [
              { $eq: ['$to.user', userId] },
              1,
              0,
            ],
          },
        },
        debitTransactions: {
          $sum: {
            $cond: [
              { $eq: ['$from.user', userId] },
              1,
              0,
            ],
          },
        },
      },
    },
  ]);

  return stats[0] || {
    totalTransactions: 0,
    totalVolume: 0,
    totalFees: 0,
    completedTransactions: 0,
    pendingTransactions: 0,
    failedTransactions: 0,
  };
};

transactionSchema.statics.getRecentTransactions = async function(limit = 10, userId = null) {
  const query = userId ? {
    $or: [
      { 'from.user': userId },
      { 'to.user': userId },
    ],
  } : {};

  return this.find(query)
    .sort({ createdAt: -1 })
    .limit(limit)
    .populate('from.user', 'firstName lastName email accountNumber')
    .populate('to.user', 'firstName lastName email accountNumber')
    .populate('giftCard');
};

module.exports = mongoose.model('Transaction', transactionSchema);