/**
 * Gift Card Model - Global Bank Nigeria
 * Real Gift Card Management System
 */

const mongoose = require('mongoose');
const crypto = require('crypto');

const giftCardSchema = new mongoose.Schema({
  // Card Information
  cardNumber: {
    type: String,
    required: true,
    unique: true,
    index: true,
  },
  cardType: {
    type: String,
    required: true,
    enum: ['amazon', 'itunes', 'google', 'apple', 'steam', 'sephora', 'global', 'visa', 'mastercard'],
  },
  cardName: {
    type: String,
    required: true,
  },
  amount: {
    type: Number,
    required: true,
    min: [0, 'Amount cannot be negative'],
  },
  currency: {
    type: String,
    default: 'USD',
  },
  
  // Card Status
  status: {
    type: String,
    enum: ['available', 'reserved', 'sold', 'used', 'expired', 'cancelled', 'fake'],
    default: 'available',
  },
  isVerified: {
    type: Boolean,
    default: true,
  },
  isFake: {
    type: Boolean,
    default: false,
  },
  isUsed: {
    type: Boolean,
    default: false,
  },
  
  // Barcode
  barcode: {
    data: String,
    format: {
      type: String,
      default: 'CODE128',
    },
  },
  
  // Ownership
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  currentHolder: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  
  // Transaction History
  transactions: [{
    type: {
      type: String,
      enum: ['generated', 'purchased', 'transferred', 'sold', 'verified', 'used'],
    },
    from: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    to: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    amount: Number,
    timestamp: {
      type: Date,
      default: Date.now,
    },
    transactionId: String,
    notes: String,
  }],
  
  // Global Card Specific (Owned by Olawale Abdul-ganiyu)
  isGlobalCard: {
    type: Boolean,
    default: false,
  },
  globalCardOwner: {
    name: String,
    email: String,
  },
  walletAddress: String,
  realWorldBankAccount: {
    bankName: String,
    accountNumber: String,
    accountName: String,
  },
  
  // Validation
  validationCode: String,
  pin: String,
  securityCode: String,
  expiryDate: Date,
  
  // Mining Information
  isMined: {
    type: Boolean,
    default: false,
  },
  minedAt: Date,
  minedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  
  // Pricing
  purchasePrice: Number,
  salePrice: Number,
  exchangeRate: Number,
  
  // Timestamps
  generatedAt: {
    type: Date,
    default: Date.now,
  },
  purchasedAt: Date,
  usedAt: Date,
  expiresAt: Date,
}, {
  timestamps: true,
});

// Indexes
giftCardSchema.index({ cardNumber: 1 });
giftCardSchema.index({ cardType: 1 });
giftCardSchema.index({ status: 1 });
giftCardSchema.index({ owner: 1 });
giftCardSchema.index({ currentHolder: 1 });
giftCardSchema.index({ isGlobalCard: 1 });

// Pre-save middleware
giftCardSchema.pre('save', async function(next) {
  if (!this.isNew) return next();

  try {
    // Generate unique card number
    if (!this.cardNumber) {
      this.cardNumber = await this.generateCardNumber();
    }

    // Generate validation code
    if (!this.validationCode) {
      this.validationCode = crypto.randomBytes(8).toString('hex').toUpperCase();
    }

    // Generate barcode data
    if (!this.barcode || !this.barcode.data) {
      this.barcode = {
        data: this.cardNumber,
        format: 'CODE128',
      };
    }

    // Set expiry date (1 year from generation)
    if (!this.expiresAt) {
      this.expiresAt = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
    }

    next();
  } catch (error) {
    next(error);
  }
});

// Instance methods
giftCardSchema.methods.generateCardNumber = async function() {
  const prefix = this.getCardPrefix();
  const random = Math.floor(Math.random() * 1000000000).toString().padStart(9, '0');
  return `${prefix}${random}`;
};

giftCardSchema.methods.getCardPrefix = function() {
  const prefixes = {
    'amazon': '1',
    'itunes': '2',
    'google': '3',
    'apple': '4',
    'steam': '5',
    'sephora': '6',
    'global': '5',
    'visa': '7',
    'mastercard': '8',
  };
  return prefixes[this.cardType] || '0';
};

giftCardSchema.methods.verify = function() {
  return {
    isValid: this.isVerified && !this.isFake && !this.isUsed && this.status === 'available',
    isUsed: this.isUsed,
    isFake: this.isFake,
    status: this.status,
    amount: this.amount,
    cardType: this.cardType,
    cardNumber: this.cardNumber,
    balance: this.amount,
  };
};

giftCardSchema.methods.transfer = function(to, transactionId) {
  if (this.status !== 'available') {
    throw new Error('Card is not available for transfer');
  }

  this.currentHolder = to;
  this.transactions.push({
    type: 'transferred',
    from: this.owner,
    to: to,
    amount: this.amount,
    transactionId,
    timestamp: new Date(),
  });

  return this.save();
};

giftCardSchema.methods.markAsUsed = function(userId) {
  this.isUsed = true;
  this.usedAt = Date.now();
  this.status = 'used';
  this.transactions.push({
    type: 'used',
    from: this.currentHolder,
    amount: this.amount,
    timestamp: new Date(),
  });

  return this.save();
};

giftCardSchema.methods.markAsSold = function(buyerId, transactionId) {
  this.status = 'sold';
  this.currentHolder = buyerId;
  this.purchasedAt = Date.now();
  this.transactions.push({
    type: 'sold',
    to: buyerId,
    amount: this.salePrice || this.amount,
    transactionId,
    timestamp: new Date(),
  });

  return this.save();
};

// Static methods
giftCardSchema.statics.findByCardNumber = function(cardNumber) {
  return this.findOne({ cardNumber });
};

giftCardSchema.statics.findAvailableByType = function(cardType) {
  return this.find({
    cardType,
    status: 'available',
    isVerified: true,
    isFake: false,
  });
};

giftCardSchema.statics.findByOwner = function(ownerId) {
  return this.find({ owner: ownerId });
};

giftCardSchema.statics.findByHolder = function(holderId) {
  return this.find({ currentHolder: holderId });
};

giftCardSchema.statics.getStatistics = async function() {
  const stats = await this.aggregate([
    {
      $group: {
        _id: '$cardType',
        total: { $sum: 1 },
        available: {
          $sum: { $cond: [{ $eq: ['$status', 'available'] }, 1, 0] },
        },
        sold: {
          $sum: { $cond: [{ $eq: ['$status', 'sold'] }, 1, 0] },
        },
        used: {
          $sum: { $cond: [{ $eq: ['$status', 'used'] }, 1, 0] },
        },
        totalValue: { $sum: '$amount' },
        totalSoldValue: {
          $sum: {
            $cond: [
              { $eq: ['$status', 'sold'] },
              '$amount',
              0,
            ],
          },
        },
      },
    },
  ]);

  const totalStats = await this.aggregate([
    {
      $group: {
        _id: null,
        totalCards: { $sum: 1 },
        availableCards: {
          $sum: { $cond: [{ $eq: ['$status', 'available'] }, 1, 0] },
        },
        soldCards: {
          $sum: { $cond: [{ $eq: ['$status', 'sold'] }, 1, 0] },
        },
        usedCards: {
          $sum: { $cond: [{ $eq: ['$status', 'used'] }, 1, 0] },
        },
        totalValue: { $sum: '$amount' },
      },
    },
  ]);

  return {
    byType: stats,
    overall: totalStats[0] || {},
  };
};

module.exports = mongoose.model('GiftCard', giftCardSchema);