/**
 * Authentication Routes - Global Bank Nigeria
 * Real Authentication System
 */

const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { validateRegistration, validateLogin, validateForgotPassword } = require('../middleware/validation');
const { authenticate } = require('../middleware/auth');
const { upload } = require('../middleware/upload');

// Public routes
router.post('/register', validateRegistration, authController.register);
router.post('/login', validateLogin, authController.login);
router.post('/forgot-password', validateForgotPassword, authController.forgotPassword);
router.post('/reset-password/:token', authController.resetPassword);
router.get('/verify-email/:token', authController.verifyEmail);
router.post('/resend-verification', authController.resendVerification);

// Protected routes
router.post('/logout', authenticate, authController.logout);
router.post('/refresh-token', authController.refreshToken);
router.post('/change-password', authenticate, authController.changePassword);
router.post('/upload-kyc', authenticate, upload.fields([
  { name: 'idDocument', maxCount: 1 },
  { name: 'passportPhoto', maxCount: 1 },
]), authController.uploadKYC);
router.get('/kyc-status', authenticate, authController.getKYCStatus);

// 2FA routes
router.post('/enable-2fa', authenticate, authController.enable2FA);
router.post('/disable-2fa', authenticate, authController.disable2FA);
router.post('/verify-2fa', authenticate, authController.verify2FA);

module.exports = router;