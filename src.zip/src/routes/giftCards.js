/**
 * Gift Card Routes - Global Bank Nigeria
 * Real Gift Card Trading System
 */

const express = require('express');
const router = express.Router();
const giftCardController = require('../controllers/giftCardController');
const { authenticate, isAdmin } = require('../middleware/auth');
const { validateGiftCardPurchase, validateGiftCardSale } = require('../middleware/validation');

// Public routes
router.get('/available', authenticate, giftCardController.getAvailableCards);
router.get('/types', authenticate, giftCardController.getCardTypes);
router.get('/rates', authenticate, giftCardController.getCurrentRates);

// Customer routes
router.post('/purchase', authenticate, validateGiftCardPurchase, giftCardController.purchaseCard);
router.post('/sell', authenticate, validateGiftCardSale, giftCardController.sellCard);
router.post('/transfer', authenticate, giftCardController.transferCard);
router.get('/my-cards', authenticate, giftCardController.getMyCards);
router.get('/:cardId', authenticate, giftCardController.getCardById);
router.post('/verify', authenticate, giftCardController.verifyCard);
router.post('/scan', authenticate, giftCardController.scanCard);

// Admin routes
router.get('/all', authenticate, isAdmin, giftCardController.getAllCards);
router.post('/generate', authenticate, isAdmin, giftCardController.generateCards);
router.post('/add-type', authenticate, isAdmin, giftCardController.addCardType);
router.put('/:cardId', authenticate, isAdmin, giftCardController.updateCard);
router.delete('/:cardId', authenticate, isAdmin, giftCardController.deleteCard);
router.get('/statistics', authenticate, isAdmin, giftCardController.getStatistics);

module.exports = router;